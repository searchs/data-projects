# Kubes/K8
# Qwiklabs:
# username: google3368856_student@qwiklabs.net
# username: google3368141_student@qwiklabs.net
# pass: 
# GCP Project ID: wiklabs-gcp-91bba9f454f627b1)

docker build -t gcr.io/qwiklabs-gcp-91bba9f454f627b1/hello-node:v1
docker run -d -p 8080:8080 gcr.io/qwiklabs-gcp-91bba9f454f627b1/hello-node:v1


# gcloud auth configure-docker
# WARNING: Your config file at [/home/google3368856_student/.docker/config.json] contains these credential helper entries:
{
  "credHelpers": {
    "gcr.io": "gcr",
    "us.gcr.io": "gcr",
    "asia.gcr.io": "gcr",
    "staging-k8s.gcr.io": "gcr",
    "eu.gcr.io": "gcr"
  }
}
These will be overwritten.
The following settings will be added to your Docker config file
located at [/home/google3368856_student/.docker/config.json]:
 {
  "credHelpers": {
    "gcr.io": "gcloud",
    "us.gcr.io": "gcloud",
    "eu.gcr.io": "gcloud",
    "asia.gcr.io": "gcloud",
    "staging-k8s.gcr.io": "gcloud",
    "marketplace.gcr.io": "gcloud"
  }
}



gcloud config set project qwiklabs-gcp-91bba9f454f627b1
# Create Clusters
gcloud container clusters create hello-world \
                --num-nodes 2 \
                --machine-type n1-standard-1 \
                --zone us-central1-a


# Create a pod
kubectl run hello-node \
    --image=gcr.io/qwiklabs-gcp-91bba9f454f627b1/hello-node:v1 \
    --port=8080


# Expose to External IP
kubectl expose deployment hello-node --type="LoadBalancer"

# kubectl get services
hello-node   LoadBalancer   10.31.244.203   <pending>     8080:30233/TCP   39s

# scale up DEPLOYMENTS
kubectl scale deployment hello-node --replicas=4

# Docker:  Build a new version of app
docker build -t gcr.io/qwiklabs-gcp-91bba9f454f627b1/hello-node:v2 .



# Session 2:   Basic Kubernetes - Deploy Cluster and App
# Cluster Auth Credentials
gcloud auth list

# Get running project(s)
gcloud config list project

# Set Cloud Region
gcloud config set compute/zone us-central1-a

# Create K8 Cluster
gcloud container clusters create my-cluster

# Get Credentails
gcloud container clusters get-credentials my-cluster

# Deploy a docker image from repo
kubectl run hello-server --image=gcr.io/google-samples/hello-app:1.0 --port 8080

# Expose Deploy using LoadBalancer
kubectl expose deployment hello-server --type="LoadBalancer"

# Check Service Details
kubectl get service hello-server

# Kill or Destroy Cluster
gcloud container clusters delete my-cluster




