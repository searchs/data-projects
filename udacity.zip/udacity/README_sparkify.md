```shell
1.  Summary of the project
2.  How to run the Python scripts and an explanation of the files in the repository
3.  Comments are used effectively and 
4.  Each function has a docstring.
```


__Discuss__ the purpose of this database in the context of the startup, Sparkify, and their analytical goals.
__State__ and justify your database schema design and ETL pipeline.
__[Optional]__ Provide example queries and results for song play analysis.


# Sparkify Data Ingestion (ETL)
Sparkify as a business, now has data relating to user activities on its platform and would love to gain some insights on user behaviour particularly the songs being played or listened to by users.  Sparkify wants to be able to extract user activities, usage details, play frequency and more information to help develop a better service for users.

The goal of this project is to create a data source (database) that allows the business easily extract relevant information from the data generated while using this music platform.   

The two main data sources to be used are the songs data and songplay log files.   All the files have been extracted and stored in the data directory on the server for future mining.

This process ingests these log files, extracts information such as the users and artists details, song details, song play time and songplay records.

Each data category will be stored either as a Fact table or a Dimension table depending on the type and purpose of data.  There will be 5 database tables at the end of the process.

A breakdown of each table is given below:

#### FACT TABLES
**SONGPLAYS:** _records in log data associated with song plays i.e. records with page NextSong_

| songplay_id | start_time | user_id |  level | song_id | artist_id | session_id | location | user_agent |
| ----------- | :--------: | ------: | -----: | ------: | --------: | ---------- | -------- | ---------- |
| _Serial_      | _Time_ |  _Text_ | _Text_ |  _Text_ |    _Text_ | _Int_      | _Text_   | _Varchar_     |

#### DIMENSION TABLES
**USERS:** _stores users of the app_
| user_id | first_name | last_name | gender | level  |
| ------- | ---------- | --------- | ------ | ------ |
| _Int_  | _Text_     | _Text_    | _Text_ | _Text_ |


**SONGS:** _songs in music database_
| song_id | title  | artist_id | year  | duration |
| ------- | ------ | --------- | ----- | -------- |
| _Text_  | _Text_ | _Text_    | _Int_ | _Numeric_    |



**ARTISTS:** _artists in music database_
| artist_id | name   | location | latitude  | longitude |
| --------- | ------ | -------- | --------- | --------- |
| _Text_    | _Text_ | _Text_   | _Numeric_ | _Numeric_ |


**TIME** _timestamps of records in songplays_

| start_time | hour  | day   | week  | month | year  | weekday |
| ---------- | ----- | ----- | ----- | ----- | ----- | ------- |
| _datetime_ | _Int_ | _Int_ | _Int_ | _Int_ | _Int_ | _Int_   |

The database schema, a star schema,  is designed with the Fact table (Songplays)central, as it contains the user activities details while the Dimension tables (users, artists, songs and time) stores user, artists, song and time keys, values and attributes.   This design allows for quick information retrieval, minimal data duplication and extendability.


#### Data Pipeline
This pipeline ingests songs and logs data files produced by Sparkify users.
It extracts and stores songs details, artists information and users listening activities in the database (Postgres)

The pipeline is written in [Python](https://en.wikipedia.org/wiki/Python_(programming_language)) and consist of data source, a Postgres database, a requirements.txt(contains a list of Python dependencies) and 3 python scripts.  The scripts have two python module dependencies: psycopg2 and pandas.   psycopg2 is used to connect to the database while pandas is used to handle the data being processed.

The Postgres database follows the schema described above.

The details of the scripts is as follows:
1.  **sql_queries.py**:  This script contains the statements(commands) to interact with the database performing any or combination of the following actions: Create, Read, Update and Delete operations. To add a new table to the pipeline or tweak the database schema, use this script.  Don't forget to add the new queries into the appropriate category - either a create_table_query or a drop_table_query. 
2.    **create_tables.py**:  This script helps to cleanup and reset the database.   This involves creating the database, dropping and creating tables.   This script depends on the sql_queries.py script.
3. **etl.py**:  Data extraction, transformation and loading functions reside in this script.  This script loads the raw logs(ingestion), clean up the data e.g. unnecessary empty values and then stores the information in the required table in the database. Any raw data manipulation activity goes into this file.   The current implementation has the log file location hard-coded, future release will take the data/log location as an argument when calling the script. 

***RAW DATA STRUCTURE***
**_Sample Song data_**
```json
{
    "num_songs": 1,
    "artist_id": "ZARD7TV1287B99BFB1",
    "artist_latitude": 102.030212,
    "artist_longitude": 180.231254,
    "artist_location": "Lagos - NG",
    "artist_name": "Kiddy Rapz",
    "song_id": "TOMZWCG12A8C13N880",
    "title": "Wanna Grow Data",
    "duration": 198.93179,
    "year": 2009
}
```
**_Sample  Songplay Log_**
```json
{
    "artist": "Kiddly Rpaz",
    "auth": "Logged In",
    "firstName": "Bob",
    "gender": "M",
    "itemInSession": 21,
    "lastName": "Marxi",
    "length": 201.68,
    "level": "paid",
    "location": "Accra, GH",
    "method": "GET",
    "page": "Downgrade",
    "registration": 1511020249796.0,
    "sessionId": 476,
    "song": null,
    "status": 200,
    "ts": 1503603993796,
    "userAgent": "\"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_9_4)
        AppleWebKit\/537.77.4 (KHTML, like Gecko) Version\/7.0.5 Safari\/537.77.4\"",
    "userId": "60"
}
```

**RUNNING THE PIPELINE**
This pipeline runs on the commandline.  To run the  pipeline, follow the steps below:
1.  Download the script to the same directory as the raw data logs
2.  Install the Python dependencies:
   ```
   pip install -r requirements.txt
   ```

3.  Run the create_tables.py script (**should not generate any error**): 
     ```shell 
     python create_tables.py
     ```
4.  Run the etl.py (**should not generate any error**):
    ```shell
    python etl.py
    ```

