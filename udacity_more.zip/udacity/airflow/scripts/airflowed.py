from datetime import datetime, timedelta
import logging
import airflow

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.postgres_hook import PostgresHook


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2019, 6, 16),
    'email': ['ola.ajibode@gmail.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}


def load():
    db_hook = PostgresHook("demo")
    df = db_hook.get_pandas_df("SELECT * FROM rideds")
    print(f'Successfully used PostgresHook to return {len(df)} records')


# load_task = PythonOperator(task_id='load', python_callable=hello_world, ...)

def greet():
    """a function for the PythonOperator to call"""
    logging.info("Allo Ola!")
    logging.info("Running the greet python_callable in the dag...")


dag = DAG('lesson_1.demo1', start_date=datetime.now())

greet_task = PythonOperator(
    task_id="greet_task",
    python_callable=greet,
    dag=dag
)

dag_backfill = DAG(
    'lesson2_backfill',
    start_date=datetime.now() - timedelta(days=60),
    schedule_interval='@monthly'
)

divvy_DAG = DAG('divvy',
                description='Analyzes the cost per click',
                start_date=datetime(2019,2,4)
                # schedule_interval='@daily'
)




# /opt/airflow/start.sh 
