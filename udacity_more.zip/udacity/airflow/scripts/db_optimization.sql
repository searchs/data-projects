-- ADDLIKES DB MANAGEMENT
SHOW GLOBAL STATUS;

-- “mysqladmin -r -i 10 extended-status | grep "Select_scan”;
SELECT * FROM sys.schema_unused_indexes;



