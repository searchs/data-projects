# Udacity Project Notes

# RedShift 
# Leader and Compute Nodes

# Solution
Copy data from Sources via S3 [can use AirFlow]

From Staging move data to Redshift [transform data before inserting in DWH]

From Redshitf ->  Data Cubes --> from where BI apps can pulll the data (dashboards for example)


# Sample COPY command
'''
COPY sporting_event_tickets FROM 's3://location'
CREDENTIALS 'aws_iam_role=arn:aws:iam:4996939393:role/dwhRole'
gzip DELIMITER ';' REGION 'us-west-2
'''

# Sample Manifest file
'''
{
    "entries":[
        {"url":"s3://xx1 ", "mandatory": true},
        {"url":"s3://xx2 ", "mandatory": true},
        {"url":"s3://xx3 ", "mandatory": true},
        {"url":"s3://xx4 ", "mandatory": true},
    ]
}
'''

# Copy with Manifest 
'''
COPY customer 
FROM 's3://location_of_manifest/cust.manifest
IAM_ROLE 'aws_iam_role=arn:aws:iam:4996939393:role/dwhRole'
manifest;
'''

# ETL Out of Redshift
'''
UNLOAD ('select * from venue limit 10') 
to 's3://bucket/venue_pipe_'
iam_role 'arn:aws:iam::09739989:role/MyRedshiftRole';

'''

# Steps
iam user: dwhadmin (admin privileges)



FACT tABLE SCHEMA
songplays 
songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent

Dimension Tables
users
user_id, first_name, last_name, gender, level

songs
song_id, title, artist_id, year, duration

artists
artist_id, name, location, lattitude, longitude

time
start_time, hour, day, week, month, year, weekday
