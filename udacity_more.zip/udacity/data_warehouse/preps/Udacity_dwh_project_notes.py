# Udacity Project Notes

# RedShift 
# Leader and Compute Nodes

# Solution
Copy data from Sources via S3 [can use AirFlow]

From Staging move data to Redshift [transform data before inserting in DWH]

From Redshitf ->  Data Cubes --> from where BI apps can pulll the data (dashboards for example)


# Sample COPY command
'''
COPY sporting_event_tickets FROM 's3://location'
CREDENTIALS 'aws_iam_role=arn:aws:iam:4996939393:role/dwhRole'
gzip DELIMITER ';' REGION 'us-west-2
'''

# Sample Manifest file
'''
{
    "entries":[
        {"url":"s3://xx1 ", "mandatory": true},
        {"url":"s3://xx2 ", "mandatory": true},
        {"url":"s3://xx3 ", "mandatory": true},
        {"url":"s3://xx4 ", "mandatory": true},
    ]
}
'''

# Copy with Manifest 
'''
COPY customer 
FROM 's3://location_of_manifest/cust.manifest
IAM_ROLE 'aws_iam_role=arn:aws:iam:4996939393:role/dwhRole'
manifest;
'''

# ETL Out of Redshift
'''
UNLOAD ('select * from venue limit 10') 
to 's3://bucket/venue_pipe_'
iam_role 'arn:aws:iam::09739989:role/MyRedshiftRole';

'''

# Steps
iam user: dwhadmin (admin privileges)
    
    
    Create Table Schemas
Design schemas for your fact and dimension tables
Write a SQL CREATE statement for each of these tables in sql_queries.py
Complete the logic in create_tables.py to connect to the database and create these tables
Write SQL DROP statements to drop tables in the beginning of create_tables.py if the tables already exist. This way, you can run create_tables.py whenever you want to reset your database and test your ETL pipeline.
Launch a redshift cluster and create an IAM role that has read access to S3.
Add redshift database and IAM role info to dwh.cfg.
Test by running create_tables.py and checking the table schemas in your redshift database. You can use Query Editor in the AWS Redshift console for this.

'''
Note
The SERIAL command in Postgres is not supported in Redshift. The equivalent in 
redshift is IDENTITY(0,1), which you can read more on in the Redshift Create Table Docs.
'''

FACT tABLE SCHEMA
songplays 
songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent

# Dimension Tables
CREATE users
user_id, first_name, last_name, gender, level

songs
song_id, title, artist_id, year, duration

artists
artist_id, name, location, lattitude, longitude

time
start_time, hour, day, week, month, year, weekday
