import scala.util.{Try, Success, Failure}

val result: Try[Int] = Try(riskyCodeInvoked("Exception Expected in certain cases"))

result match {
  case Success(res) => info("Operation Was successful")
  case Failure(ex: ArithmeticException) => error("ArithmeticException occurred", ex)
  case Failure(ex) => error("Some Exception occurred", ex)
}

