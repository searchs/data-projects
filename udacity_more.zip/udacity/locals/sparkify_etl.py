import os
import time

import pyspark
from pyspark import SparkConf
from pyspark import SparkContext as sc 
from pyspark.sql import SparkSession, SQLContext

"""How to run script
    local-mode:
    ~/.sdkman/candidates/spark/current/bin/spark-submit ./sparkify_etl.py
    
    cluster mode-yarn:
    ~/.sdkman/candidates/spark/current/bin/spark-submit --master yarn ./sparkify-etl.py
    
"""


if __name__ == "__main__":
    """Spark ETL script"""
    
    spark = SparkSession \
        .builder \
        .appName("Dashboard Generator") \
        .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    print("====== SPARK CONFIG ===========")
    # print(spark.sparkContext.getConf().getAll().foreach(print))
    configs = spark.sparkContext.getConf().getAll()
    for config in configs:
        print(config)
        
    print("====== END OF SPARK CONFIG ===========")
   
    ''' 
    incorrect_records = SparkContext.accumulator(0, 0)
    
    print(incorrect_records)
    
    def add_incorrect_records():
        global incorrect_records
        incorrect_records += 1
        
    from pyspark.sql.functions import udf
    correct_ts = udf(lambda x:  1 if x.isdigit() else add_incorrect_records())
    '''
    
    
    # if using S3
    # data = "s3://sparkify/sparkify_log_small.json"
    # From HDFS
    # data = "hdfs:///user/sparkify_data/sparkify_log_small.json"

    log_of_songs = ["Despicado", "Carlos Santana", "Shina Peters", "Adewale Ayuba", "Spies Group"]
    # log_of_songs = spark.read.json(data)     
    distributed_song_log = spark.sparkContext.parallelize(log_of_songs)
    distributed_song_log.persist() #speed up reading data
    
    # CORRUPT RECORDS
    # distributed_song_log.where(distributed_song_log["_corrupt_record"].isNotNull()).collect()
    # distributed_song_log.where(distributed_song_log["_corrupt_record"].isNotNull()).collect()

    
    print("=" * 89)
    print(distributed_song_log.map(lambda song: song.lower()).collect())
    # print(distributed_song_log.map(lambda song: song.lower().collect()))
    print("=" * 89)
    
    
    # SYSYTEM ANALYSIS
    syslog = "/var/log/system.log"
    # df_sys = spark.read.text(syslog)
    # df_sys = SparkContext.textFile(syslog)
    df_sys = spark.sparkContext.textFile(syslog)
    
    # print(df_sys.describe().show(truncate=False, vertical=True))
    
    # broken = df_sys.show(2)
    df_sys.persist()
    # df_broken = df_sys.foreach(map(lambda line: line.split(" "), f))
    try:
        counts = df_sys.flatMap(lambda line: line.split(" ")) \
                .map(lambda word: (word, 1)) \
                .reduceByKey(lambda a,b: a + b ) \
                .sortByKey(True)
    
        current_time = str(int(round(time.time() * 10,0)))
        print(current_time)
        # Cleanup existing results before save
        os.system("rm -rf results_*")
        
        counts.saveAsTextFile("results_" + current_time + ".txt")
    except Exception as ee:
        print("ERROR:  Something is not right!\n")
        print(ee)
    finally:
        print("\n" + "*" * 99)
        print("\nData processing now complete.\n")
        print("*" * 99)
    
    
    
    spark.stop()
    
    # consAPIKEY:Ee4lavQ6ifnnWs7YziQ1Md4VB
    # consuSecret:nlbdlEgYPgDGpqtxXPtHVjnReX98n5M9A44kjJdMBecDbn7FSW
    
    # AccessTk:247245064-pz6PceQAoaReryvuNRoJ51f6e1cLLHNM5hIhbNge
    # AccessSec:HNnShCY04XsN5pWdpNHR4GQn6fDF0uRaqMVSiiS8S9dEy    