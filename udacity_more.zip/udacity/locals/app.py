ss = {"Ola", "Ade"}
ss.add("Olu")

print(type(ss))

print(ss)

dd = {"location": "London"}
print(type(dd))