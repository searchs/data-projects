#!/usr/bin/env python
# coding: utf-8

# In[4]:


# !pip install tweepy

import tweepy
from tweepy.auth import OAuthHandler
from tweepy import Stream


# In[5]:


from tweepy.streaming import StreamListener


# In[6]:


import socket
import json


# In[7]:


consumer_key = 'Ee4lavQ6ifnnWs7YziQ1Md4VB'
consumer_secret = 'nlbdlEgYPgDGpqtxXPtHVjnReX98n5M9A44kjJdMBecDbn7FSW'
access_token = '247245064-pz6PceQAoaReryvuNRoJ51f6e1cLLHNM5hIhbNge'
access_secret = 'HNnShCY04XsN5pWdpNHR4GQn6fDF0uRaqMVSiiS8S9dEy'


# In[13]:


class TweetsListener(StreamListener):
    
    def __init__(self, csocket):
        self.client_socket = csocket
        
    def on_data(self, data):
        try:
            msg = json.loads(data)
            print(msg['text'].encode('utf-8'))
            return True
        except BaseException as e:
            print("Error on data: %s" % str(e))
        return True
    
    def on_error(self, status):
        print(status)
        return True


# In[12]:


def sendData(c_socket):
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_secret)
    
    twitter_stream = Stream(auth, TweetsListener(c_socket))
    twitter_stream.filter(track=['football'])
    


# In[ ]:


if __name__ == "__main__":
    s = socket.socket()
    host = "127.0.0.1"
    port = 5559
    s.bind((host, port))
    
    print("Listening on port: %s" % str(port))
    
    s.listen(5)
    c, addr = s.accept()
    
    print("Received request from :" + str(addr))
    sendDate(c)

