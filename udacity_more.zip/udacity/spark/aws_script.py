# Sample Spark script for AWS
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import udf

'''
To run the script, follow the steps below
bash command: /usr/bin/spark-submit --master yarn  ./aws_script.py

'''

if __name__ == "__main__":
    """Spark script for ingestion and analysis"""
    
    # spark = SparkSession \
    #     .builder \
    #     .appName("LowerSongTitles") \
    #     .getOrCreate()

    spark = SparkSession.builder.config("spark.ui.port", 3000).getOrCreate()

    incorrect_records = SparkContext.accumulator(0, 0)
    print(incorrect_records)

    def add_incorrect_record():
        global incorrect_records
        incorrect_records += 1
    
    correct_ts = udf(lambda x: 1 if x.isdigit() else add_incorrect_record())

    log_of_songs = [
        "Desperado",
        "Despacito",
        "No tears left to cry",
        "Nice for What",
        "Despicato",
        "Havana",
        "In my feelings",
        "Nice for What",
        "Despicato",
        "All the stars"
    ]

    distributed_song_log = spark.sparkContext.parallelize(log_of_songs)

    print(distributed_song_log.map(lambda x: x.lower()).collect())

    # datasource = "s3a://sparkify/sparkify_log_email.json"

    datasource = "/var/log/system.log"

    df_mac = spark.read.text(datasource)
    df_mac.persist()

    df_mac.printSchema()

    df_mac.show(5)

    spark.stop()
    
    '''
    # ip address for project: 10.23.1.226
    ip_address = '10.23.1.226' #master node?
    host = '10.23.7.48'
    # 10.63.158.54 - Tunnel IP
    applicationMaster_host = '10.23.7.4'
    '''

    # ewe-data-science-bigdata/ede-ds/prod/hotel-attribution/etl-metrics

    def until(n, filter_func, v):
        if v == n: return []
        if filter_func(v): return [v] + until(n, filter_func, v+1)
        else: return until(n, filter_func, v+1)

    multi_3_5 = lambda x: x % 3 == 0 or x % 5 == 0

    until(10, multi_3_5, 0)
