
# Project: qwiklabs-gcp-a2aa329e275dfb5b


sudo -i
# As root
   1  apt-get update
    2  apt-get install -y protobuf-compiler python-pil python-lxml python-pip python-dev git
    3  pip install Flask==0.12.2 WTForms==2.1 Flask_WTF==0.14.2 Werkzeug==0.12.2
    4  pip install --upgrade https://storage.googleapis.com/tensorflow/linux/cpu/tensorflow-1.1.0-cp27-none-linux_x86_64.whl
    5  cd /opt
    6  git clone https://github.com/tensorflow/models
    7  cd models/research
    8  protoc object_detection/protos/*.proto --python_out=.
    9  mkdir -p /opt/graph_def
   10  cd /tmp
   11  for model in   ssd_mobilenet_v1_coco_11_06_2017   ssd_inception_v2_coco_11_06_2017   rfcn_resnet101_coco_11_06_2017   faster_rcnn_resnet101_coco_11_06_2017   faster_rcnn_inception_resnet_v2_atrous_coco_11_06_2017; do   curl -OL http://download.tensorflow.org/models/object_detection/$model.tar.gz;   tar -xzf $model.tar.gz $model/frozen_inference_graph.pb;   cp -a $model /opt/graph_def/; done
   12  ln -sf /opt/graph_def/faster_rcnn_resnet101_coco_11_06_2017/frozen_inference_graph.pb /opt/graph_def/frozen_inference_graph.pb
   13  history



# After running systemctl daemon-reload
# The application provides a simple user authentication mechanism. You can change the default username 
# and password by modifying the `/opt/object_detection_app/decorator.py` file and changing the following 
# lines: `USERNAME = 'username' PASSWORD = 'passw0rd'` 

# Found ERROR: Error: Malformed URL



# MODEL NAMES


    ssd_mobilenet_v1_coco_11_06_2017
cmd:    ln -sf /opt/graph_def/ssd_mobilenet_v1_coco_11_06_2017/frozen_inference_graph.pb /opt/graph_def/frozen_inference_graph.pb
    ssd_inception_v2_coco_11_06_2017

    rfcn_resnet101_coco_11_06_2017

    faster_rcnn_resnet101_coco_11_06_2017

    faster_rcnn_inception_resnet_v2_atrous_coco_11_06_2017
ln -sf /opt/graph_def/ssd_mobilenet_v1_coco_11_06_2017/frozen_inference_graph.pb /opt/graph_def/frozen_inference_graph.pb







