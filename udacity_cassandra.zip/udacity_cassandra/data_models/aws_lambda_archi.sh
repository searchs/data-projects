# AWS Lambda Architecture
bucket_src=images-2580
bucket_dest=images-2580-resized

# upload image to src bucket

# LAMBDA
# Create Lambda: Permissions: Execution/Existing(e.g. Lambda-Execution-Role)

lambda_function.lambda_handler
CreateThumbnail.handler


# Amazon S3 link URL:  Holds the lambda function
