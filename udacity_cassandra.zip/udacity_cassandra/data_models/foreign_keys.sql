-- bB DEFAULT Primary Key cannot be NULL

CREATE TABLE vendors(
    vendor_code integer PRIMARY KEY,
    vendor_name character(35),
    vendor_city character(15),
    vendor_country character(20)
    );


CREATE TABLE items(
    item_code integer NOT NULL,
    item_name character(35) NOT NULL,
    purchase_unit character(10),
    sale_unit character(10),
    purchase_price numeric(10,2),
    sale_price numeric(10,2),
    PRIMARY KEY (item_code,item_name)
        );


CREATE TABLE orders(
    ord_no integer PRIMARY KEY,
    ord_date date,
    item_code integer REFERENCES items(item_code),
    item_grade character(1),
    ord_qty numeric,
    ord_amount numeric
);


-- Multiple Foreign Keys
CREATE TABLE items(
    item_code integer PRIMARY KEY,
    item_name character(35),
    purchase_unit character(10),
    sale_unit character(10),
    purchase_price numeric(10,2), --field size(10), decimal places(2)
    sale_price numeric(10,2)
    );

-- Order table with Foregin Keys
CREATE TABLE orders(
    ord_no integer,
    ord_date date,
    item_code integer REFERENCES items,
    vendor_code integer REFERENCES vendors,
    item_grade character(1),
    ord_qty numeric,
    ord_amount numeric,
    PRIMARY KEY (item_code,vendor_code)
    );







