"""Sparkify - EXTRACT TRANSFORM LOAD Engine
This pipeline ingests songs and logs datafiles produced by Sparkify users.
It stores songs details, artists information and users listening activities
in the database (Postgres)"""

import os
import glob
import psycopg2
import pandas as pd
from sql_queries import song_table_insert, user_table_insert, \
                artist_table_insert, songplay_table_insert, \
                time_table_insert, song_select


def process_song_file(cur, filepath):
    """Processes song files extracting song and artist details.

    Parameters:
    cur:  Database cursor. Access the database for various operations

    filepath:  Location of files to be processed
    """
    # open song file
    dataframe = pd.read_json(filepath, lines=True)

    # insert song record
    song_data = list(dataframe.loc[:, ['song_id', 'title', 'artist_id',
                                       'year',
                                       'duration']].values[0])
    cur.execute(song_table_insert, song_data)

    # insert artist record
    artist_data = list(dataframe.loc[:,
                                     ['artist_id',
                                      'artist_name',
                                      'artist_location',
                                      'artist_latitude',
                                      'artist_longitude']].values[0])
    cur.execute(artist_table_insert, artist_data)


def process_log_file(cur, filepath):
    """Process log files containing user songplay activities.

    Parameters:
    -----------
    cur:  Cursor to the database

    filepath:  Location of log file
    """

    # open log file
    dataframe = pd.read_json(filepath, lines=True)

    # filter by NextSong action
    dataframe = dataframe[dataframe['page'] == 'NextSong']

    # convert timestamp column to datetime
    ts_conv = pd.to_datetime(dataframe['ts'], unit='ms')

    # insert time data records
    time_data = (ts_conv.dt.time.values, ts_conv.dt.hour.values,
                 ts_conv.dt.month.values, ts_conv.dt.year.values,
                 ts_conv.dt.weekday.values)
    time_df = pd.DataFrame(dict(zip(
        ('start_time',
         'hour', 'day', 'week', 'month', 'year', 'weekday'), time_data)))

    for idx, row in time_df.iterrows():
        cur.execute(time_table_insert, list(row))

    # load user table
    user_df = pd.DataFrame(dataframe.loc[:, ['userId', 'firstName',
                                             'lastName', 'gender', 'level']])

    # Remove duplicate data based on user_id before insert
    user_df = user_df.drop_duplicates(['userId'])

    # insert user records
    for idx, row in user_df.iterrows():
        try:
            cur.execute(user_table_insert, row)
        except psycopg2.Error as error:
            print(error)
            cur.execute("rollback;")
        finally:
            print("Final user in index:{0} processed.".format(idx))

    # insert songplay records
    for idx, row in dataframe.iterrows():
        # get songid and artistid from song and artist tables
        try:
            cur.execute(song_select, (row.song, row.artist, row.length))
            results = cur.fetchone()

            if results:
                songid, artistid = results
            else:
                songid, artistid = None, None

            # insert songplay record
            playtime = pd.to_datetime(row['ts'], unit='ms')
            songplay_data = (playtime.time().strftime("%H:%M:%S"),
                             row.userId, row.level, songid,
                             artistid, row.sessionId,
                             row.location, row.userAgent)
            try:
                cur.execute(songplay_table_insert, songplay_data)
                print("Process record at index: {0}".format(idx))
            except psycopg2.Error as error:
                print(error)
        except psycopg2.Error as error:
            print(error)
            continue


def process_data(cur, conn, filepath, func):
    """Accepts cursor to database, a database connection, a filepath
    and a function.

    The process_song_file and process_log_file can be passed to extract
    the required data.

    Parameters:
    -----------
    cur:  Cursor to the database
    conn:  Database connection string
    filepath:  Location of files to be processed.
    func:  Function to run

    """
    # get all files matching extension from directory
    all_files = []
    for root, dirs, files in os.walk(filepath):
        if root:
            print("Main Root: {0}".format(root))
        if dirs:
            print("Directory: {0}".format(dirs))

        files = glob.glob(os.path.join(root, '*.json'))
        for raw_file in files:
            all_files.append(os.path.abspath(raw_file))

    # get total number of files found
    num_files = len(all_files)
    print('{0} files found in {1}'.format(num_files, filepath))

    # iterate over files and process
    for idx, datafile in enumerate(all_files, 1):
        func(cur, datafile)
        conn.commit()
        print('{}/{} files processed.'.format(idx, num_files))


def main():
    """Runs the pipeline"""
    conn = psycopg2.connect("host=127.0.0.1 dbname=sparkifydb \
        user=student password=student")
    cur = conn.cursor()

    process_data(cur, conn, filepath='data/song_data', func=process_song_file)
    process_data(cur, conn, filepath='data/log_data', func=process_log_file)

    conn.close()


if __name__ == "__main__":
    main()
