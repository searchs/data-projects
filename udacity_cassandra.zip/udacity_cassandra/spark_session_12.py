import findspark
findspark.init('spark')

import pyspark
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession

# SPARKSESSION
spark = SparkSession.builder
                    .appName("app_name")
                    .config("config option", "config value")
                    .getOrCreate()




sc = pyspark.SparkContext(appName="maps_and_lazy_evaluation_example")

dist_song_log = sc.parallelize(log_of_songs)

def convert_song_to_lowercase(song):
    return song.lower()

# Map operations
dist_song_log.map(convert_song_to_lowercase)

dist_song_log.collect()


dist_song_log.map(lambda song: song.lower()).collect()

user_log.write.save(out_path, format="csv", header=True)


# from pyspark.sql import functions
user_log.select("page").dropDuplciates().sort("page").show()

import datetime

get_hour = udf(lambda x: datetime.datetime.fromtimestamp(x/1000.0).hour)
user_log = user_log.withColumn("hour", get_hour(user_log.ts))

user_log.head()

songs_in_hour = user_log.filter(user_log.page == "NextSong").groupby(user_log.hour).count().orderBy(user_log.hour.cast("float"))
songs_in_hour.show()

import pandas as pd
import matplotlib.plotly as plt

# Visualize
songs_in_hour_pd = songs_in_hour.toPandas()

plt.scatter(songs_in_hour_pd["hour"], songs_in_hour_pd["count"])
plt.xlim(-1,24);
plt.ylim(0, 1.2 * max(songs_in_hour_pd["count"]))
plt.xlabel("Hour")
plt.ylabel("Songs played");


# Missing Values
user_log_valid = user_log.dropna(how="any", subnet=["userId", "sessionId"])
user_log_valid.count()

# Remove empty strings in userId
user_log_valid = user_log_valid.filter(user_log_valid["userId"] != "")
user_log_valid.count()


# Downgrade
flag_downgrade_event =  udf(lambda x: 1 if x == "Submit Downgrade" else 0, IntegerType())
user_log_valid = user_log_valid.withColumn("downgraded", flag_downgrade_event("page"))
user_log_valid.head()


from pyspark.sql import Window

windowval = Window.partitionBy("userId").orderBy(desc("ts")).rangeBetween(Window.unboundedPreceding, 0)

user_log_valid = user_log_valid.withColumn("phase", Fsum("downgraded").windowval)

# Extract data
user_log_valid.select(["userId", "firstname", "ts", "page", "level", "phase"]).where(user_log.userId == "1138").sort("ts").collect()


