## TO-DO: Query 2: Give me only the following: name of artist, song (sorted by itemInSession) and user (first and last name)\
## for userid = 10, sessionid = 182
# Drop first
query = "DROP TABLE IF EXISTS songplays"
try:
    rows = session.execute(query)
except Exception as e:
    print(e)

# Create table now
query = "CREATE TABLE IF NOT EXISTS songplays "
query = query + "(artist text, user_first_name text, itemInSession int, user_last_name text, sessionId int, \
song_title text, userId int, PRIMARY KEY ((userId, sessionId), itemInSession, user_first_name, user_last_name))"

try:
    session.execute(query)
except Exception as e:
    print(e)

# INGEST data from csv
file = 'event_datafile_new.csv'
with open(file, encoding = 'utf8') as f:
        csvreader = csv.reader(f)
        next(csvreader) # skip header
        for line in csvreader:
    # Assign the INSERT statements into the `query` variable
            query = "INSERT INTO songplays (artist, user_first_name, itemInSession, user_last_name, sessionId, song_title, userId)"
            query = query + "VALUES (%s, %s, %s, %s, %s, %s, %s)"
            session.execute(query, (line[0], line[1], int(line[3]), line[4], int(line[8]), line[9], int(line[10])))


# Query data
query = "select artist, song_title, itemInSession, user_first_name, user_last_name FROM songplays WHERE userid=10 AND sessionId=182"
try:
    results = session.execute(query)
except Exception as e:
    print(e)

# Check results
for result in results:
    print(result)



## TO-DO: Query 3: Give me every user name (first and last) in my music app history who listened to the song 'All Hands Against His Own'
# Drop existing table first
query = "DROP TABLE IF EXISTS songplays"
try:
    rows = session.execute(query)
except Exception as e:
    print(e)

# Create a new table now
query = "CREATE TABLE IF NOT EXISTS songplays "
query = query + "(user_first_name text, user_last_name text, song_title text, userId int, PRIMARY KEY ((song_title), userId))"

try:
    session.execute(query)
except Exception as e:
    print(e)

# INGEST data from csv
file = 'event_datafile_new.csv'
with open(file, encoding = 'utf8') as f:
        csvreader = csv.reader(f)
        next(csvreader) # skip header
        for line in csvreader:
    # Assign the INSERT statements into the `query` variable
            query = "INSERT INTO songplays (user_first_name, user_last_name, song_title text, userId userId)"
            query = query + "VALUES (%s, %s, %s, %s)"
            session.execute(query, (line[1], line[4], line[9], line[4], int(line[10])))


# Query data
query = "select user_first_name, user_last_name FROM songplays WHERE song_title='All Hands Against His Own'"
try:
    results = session.execute(query)
except Exception as e:
    print(e)
    
# Check Results
for result in results:
    print(result.user_first_name, result.user_last_name)    






# DATA SLICING DICING

%%time
%%sql

SELECT dd.day as day,
        dm.rating as rating,
        ds.city as city,
        SUM(f.sales_amount) as revenue
FROM factSales f
JOIN dimDate dd ON (dd.date_key = f.date_key)
JOIN dimMovie dm ON (dm.film_id  = f.movie_key)
JOIN dimStore ds ON (ds.store_id = f.store_key)
GROUP BY day, rating, city
ORDER BY revenue DESC
LIMIT 20;


%%time
%%sql

SELECT dd.day as day,
        dm.rating as rating,
        dc.city as city,
        SUM(f.sales_amount) as revenue
FROM factSales f
JOIN dimDate dd ON (dd.date_key = f.date_key)
JOIN dimMovie dm ON (dm.movie_key  = f.movie_key)
JOIN dimCustomer dc ON (dc.customer_key = f.customer_key)
WHERE dm.rating = 'PG-13'
GROUP BY day, rating, city
ORDER BY revenue DESC
LIMIT 20;




%%time
%%sql

SELECT dd.day as day,
        dm.rating as rating,
        ds.city as city,
        SUM(f.sales_amount) as revenue
FROM factSales f
JOIN dimDate dd ON (dd.date_key = f.date_key)
JOIN dimMovie dm ON (dm.film_id  = f.movie_key)
JOIN dimStore ds ON (ds.store_id = f.store_key)
WHERE dm.rating IN ('PG' ,'PG-13')
AND ds.city IN ('Bellevue', 'Lancaster')
AND dd.day IN (1, 15, 30)
GROUP BY day, rating, city
ORDER BY revenue DESC
LIMIT 20;





SELECT dd.day as day,
        dm.rating as rating,
        dc.country as country,
        SUM(f.sales_amount) as revenue
FROM factSales f
JOIN dimDate dd ON (dd.date_key = f.date_key)
JOIN dimMovie dm ON (dm.movie_key  = f.movie_key)
JOIN dimCustomer dc ON (dc.customer_key = f.customer_key)
GROUP BY (day, rating, country)
ORDER BY revenue DESC
LIMIT 20;


grouping sets( (), dimDate.month, dimCustomer.count)

Postgres library: cstore_fdw (columnar storage)
